# Track Title (v1.0.0)

This folder contains the full metadata and supporting files for a Cypherpop Protocol-compliant track.

## Contents

- `track.json` — Structured metadata
- `lyrics.txt` — Raw lyrics
- `decoded-lyrics.md` — Lyric breakdown, references, metaphors, and decoding
